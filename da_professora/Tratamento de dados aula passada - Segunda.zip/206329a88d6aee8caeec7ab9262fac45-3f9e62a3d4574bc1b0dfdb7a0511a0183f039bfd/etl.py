import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Backend para ambientes sem interface gráfica
import matplotlib.pyplot as plt

# Lê o Data Mart
df = pd.read_csv("data/filmes_genero_ficcao.csv")

# Dashboard 1: quantidade de filmes por ano
ax1 = df.groupby("ano_lancamento")["titulo"].count().plot(kind="bar", figsize=(8,5))
plt.title("Número de Filmes por Ano")
plt.xlabel("Ano de Lançamento")
plt.ylabel("Quantidade de Filmes")
plt.tight_layout()
plt.savefig("data/dashboard_filmes_por_ano.png")
plt.close()

# Dashboard 2: nota média por ano
ax2 = df.groupby("ano_lancamento")["nota_imdb"].mean().plot(kind="line", marker="o", figsize=(8,5))
plt.title("Nota Média dos Filmes por Ano")
plt.xlabel("Ano de Lançamento")
plt.ylabel("Nota Média")
plt.tight_layout()
plt.savefig("data/dashboard_nota_media_por_ano.png")
plt.close()

print("✅ Dashboards salvos como PNG!")
