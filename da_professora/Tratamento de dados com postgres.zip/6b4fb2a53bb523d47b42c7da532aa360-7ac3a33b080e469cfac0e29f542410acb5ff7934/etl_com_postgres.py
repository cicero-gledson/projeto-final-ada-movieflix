import pandas as pd
from sqlalchemy import create_engine, text
import time
import os


PG_USER = os.getenv("PG_USER", "user")
PG_PASS = os.getenv("PG_PASS", "secret")
PG_DB   = os.getenv("PG_DB", "dw")
PG_HOST = os.getenv("PG_HOST", "pg-dados")  # hostname do container Postgres na rede docker
PG_PORT = os.getenv("PG_PORT", "5432")

# string de conexão 
conn_str = f"postgresql+psycopg2://{PG_USER}:{PG_PASS}@{PG_HOST}:{PG_PORT}/{PG_DB}"

print("Conexão:", conn_str)

time.sleep(3)


engine = create_engine(conn_str, echo=False)


import unicodedata
csv_path = "data/filmes_raw.csv"
print("Lendo CSV:", csv_path)
df = pd.read_csv(csv_path)

# Padronizar nomes das colunas: remover espaços e acentos
def normalize_col(col):
    col = col.strip()
    col = unicodedata.normalize('NFKD', col).encode('ASCII', 'ignore').decode('ASCII')
    col = col.replace(' ', '_').replace('-', '_')
    return col.lower()

df.columns = [normalize_col(c) for c in df.columns]

# 2) TRANSFORM: renomear colunas simples 
df = df.rename(columns={
    "titulo": "titulo",
    "anolancamento": "ano_lancamento",
    "ano_lancamento": "ano_lancamento",
    "genero": "genero",
    "nota_imdb": "nota_imdb"
})


# Garantir colunas esperadas (se não existir, cria com NaN)
for col in ["titulo", "ano_lancamento", "genero", "nota_imdb"]:
    if col not in df.columns:
        df[col] = None

# Remover colunas extras que não são esperadas pelo banco
df = df[["titulo", "ano_lancamento", "genero", "nota_imdb"]]

# Tratar dados simples
df["titulo"] = df["titulo"].astype(str).str.strip()
# remover espaços extras em genero
df["genero"] = df["genero"].astype(str).str.strip()
# converter ano e nota com valores default quando faltam
df["ano_lancamento"] = pd.to_numeric(df["ano_lancamento"], errors="coerce").fillna(0).astype(int)
df["nota_imdb"] = pd.to_numeric(df["nota_imdb"], errors="coerce").fillna(0.0).astype(float)


print("Preview após transformação:")
print(df.head())

# 3) LOAD: gravar no Postgres - Data Warehouse (tabela 'filmes')
with engine.begin() as conn:
    # criar schema/tabela caso não exista (cria via SQL simples)
    create_table_sql = """
    CREATE TABLE IF NOT EXISTS filmes (
        id SERIAL PRIMARY KEY,
        titulo TEXT,
        ano_lancamento INTEGER,
        genero TEXT,
        nota_imdb REAL
    );
    """
    conn.execute(text(create_table_sql))

    conn.execute(text("TRUNCATE TABLE filmes;"))


df.to_sql("filmes", engine, if_exists="append", index=False)

print("✅ Dados carregados na tabela 'filmes' (Data Warehouse).")

# 4) Criar Data Mart (ex.: filmes de Ficção Científica) como tabela materializada simples
mart_query = """
CREATE TABLE IF NOT EXISTS filmes_mart AS
SELECT titulo, ano_lancamento, nota_imdb
FROM filmes
WHERE genero ILIKE 'Fic%%'  -- pega 'Ficção Científica' e variações
;
-- Se a tabela já existir, vamos truncar e reinserir abaixo
"""

with engine.begin() as conn:
    conn.execute(text("DROP TABLE IF EXISTS filmes_mart;"))
    conn.execute(text("""
        CREATE TABLE filmes_mart AS
        SELECT titulo, ano_lancamento, nota_imdb
        FROM filmes
        WHERE genero ILIKE 'Fic%%';
    """))

print("✅ Data Mart 'filmes_mart' criado.")

with engine.connect() as conn:
    total = conn.execute(text("SELECT COUNT(*) FROM filmes;")).scalar()
    mart_total = conn.execute(text("SELECT COUNT(*) FROM filmes_mart;")).scalar()
    print(f"Registros no Warehouse (filmes): {total}")
    print(f"Registros no Data Mart (filmes_mart): {mart_total}")

print("Fim do ETL.")
